# autoosc

This is sample for automatic Opensuse Build Service
hehe
toshiba
